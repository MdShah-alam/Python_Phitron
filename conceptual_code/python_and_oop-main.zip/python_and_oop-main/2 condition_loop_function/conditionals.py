biryani_price = 130
kabab_price = 45

if biryani_price < 150 :
    print('Sultan e khamu fokir homu')
elif kabab_price < 50:
    print('kabab and naan, aram kore khan')
else:
    print('butter bon khamu cha diya')