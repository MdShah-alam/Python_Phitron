number = 1
while number < 5:
    # print(number)
    number = number + 1

total = 0
num = 1
while num <= 5:
    total = total + num
    num = num + 1
    print(total)
print('outside of while')