salary = 50000
has_flat = True

if salary > 35000:
    if has_flat == True:
        print('Ok tomar jonno manus ase')
    else: 
        print('tor kopale kichu nai')
        print('But dont worry. enjoy your life')
else:
    print('Bepar na. sobar ekdin somoy asbe')
