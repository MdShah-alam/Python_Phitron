country = 'Bangladesh'

# for letter in country:
#     print(letter)

# for num in range(5):
#     print(num)

# for index in range(6, 13):
#     print(index)

for n in range(5, 45, 5):
    print(n)