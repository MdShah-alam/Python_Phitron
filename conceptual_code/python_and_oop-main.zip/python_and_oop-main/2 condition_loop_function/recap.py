price = 8000
# This is a comment
country = 'Bangladesh'
is_rich = True
# variable
# variable types: type
# output: print
# input
# int
district = input('Where do you live: ')
print(f'This person lives in {district}')