# 6 types of comparison
# < checks whether the left side of the symbol is smaller than the right side
# > (Checks bigger or not)
# <= (checks whether smaller or equal)
# >= (checks whether bigger or equal)
# == check whether both the values are equal
# != check whether both the values are not equal


# print(12 < 35)
# print(42 < 35)

# print(12 > 56)
# print(89 > 12)

print(12 >= 12)

print(9 <= 9)

my_money = 45
your_money = 65

print(my_money == your_money)

print(my_money != your_money)