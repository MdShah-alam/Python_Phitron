'''
1. compare 
< > <= >= == !=

2. conditionals
if else
if elif else

3. while loop

4. break continue

5. for loop

'''

'''
1. Print out odd numbers between 13 to 39
2. use for loop to print numbers between 13 to 39 using and range 
3. (challenging) print out 20 to 1 using while loop (reverse way)
'''