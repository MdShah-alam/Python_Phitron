num = 1 
while num <= 10:
    print(num)
    num = num + 1


sum = 0
num = 1
while num <= 10:
    sum = sum + num
    num = num + 1
print(sum)