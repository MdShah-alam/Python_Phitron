exam = 'Private Job'
passed = False
second = 'Bank'


if exam == 'BCS' and passed == True:
    print('WOW tor biye to pakka')
    print('Congrats Mamma')
else:
    print('to biye hobe na')


if exam == 'BCS' or second == 'Bank':
    print('tor life to set hoye gese')
else:
    print('Tui ki ajibon bekar thakbi')

# if exam == 'BCS':
#     print('biyer bazare dami patro patri')

# if passed == True:
#     print('congrats')
# else: 
#     print('try next time again')