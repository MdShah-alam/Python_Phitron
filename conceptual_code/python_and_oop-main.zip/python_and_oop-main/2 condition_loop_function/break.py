num = 1
while num <= 15:
    print(num)
    if num == 7:
        break
    num  = num + 1