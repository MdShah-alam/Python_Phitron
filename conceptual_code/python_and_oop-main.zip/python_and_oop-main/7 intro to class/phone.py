class Phone:
    brand = 'Samsung'
    color = 'Black'
    price = 25000

my_phone = Phone()
print(my_phone)
print(my_phone.brand)
print(my_phone.price)
print(my_phone.color)

your_phone = Phone()

her_phone = Phone()

dad_phone = Phone()

print(dad_phone.brand)
print(your_phone.brand)
print(her_phone.brand)