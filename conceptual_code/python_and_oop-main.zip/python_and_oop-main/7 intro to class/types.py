price = 120
name = 'BanGlaDesh'
is_rich = False
numbers = [12,45,78]
print(type(price))
print(name.lower())
print(type(is_rich))
print(type(numbers))