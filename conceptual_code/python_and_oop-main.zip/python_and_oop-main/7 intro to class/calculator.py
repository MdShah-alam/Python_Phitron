class Calculator:
    def add():
        pass
    def subtract():
        pass
    def multiply():
        pass
    def divide():
        pass