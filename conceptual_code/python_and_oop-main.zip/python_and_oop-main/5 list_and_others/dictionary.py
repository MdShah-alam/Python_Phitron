# numbers = [12, 45, 56, 45, 12, 89]
marks = { 'physics': 12, 'chemistry': 45, 'math': 56 }
marks['math'] = 56.5
marks['english'] = 89
# del marks['chemistry']
# print(marks)
marks_keys = marks.keys()
marks_values = marks.values()
marks_items = marks.items()
# marks.clear()
# print(marks_items)
