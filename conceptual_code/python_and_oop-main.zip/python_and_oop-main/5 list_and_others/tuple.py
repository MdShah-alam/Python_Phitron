numbers = [12, 45, 56, 45, 12, 89]
# print(numbers)
numbers_tuple = 12, 45, 56, 45, 12, 89
# nums_tuple = (12,45,56)
# print(numbers_tuple)
# numbers_tuple[2] = 44
# del numbers_tuple[1]
# print(numbers_tuple[3])

tuple2D = ([12,45, 12], [45, 11, ])
tuple2D[0][1] = 99
print(tuple2D)

short_tuple = 2,

tuple_from_list = tuple(numbers)
print(tuple_from_list)