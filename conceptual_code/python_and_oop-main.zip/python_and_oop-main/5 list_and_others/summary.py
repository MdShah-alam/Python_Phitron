numbers = [ 12, 45, 65, 23, 89, 78, 11, 10]

if 45 in numbers:
    print('found it')

if 45 not in numbers:
    print('not found it')

for a in numbers:
    pass