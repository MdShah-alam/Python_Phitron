weight = 58
weight_type = type(weight)
print(weight_type) 
price = 13.79
price_type = type(price)
print(price_type)


pen = 'ECONO'
print(type(pen))

kanamachi = True
print(type(kanamachi))
person = 'Kodom Ali'
age = 45
# about_me = 'My Name is' + person + age
about_me = f'My Name is {person}. My age is {age}.'
print(about_me)