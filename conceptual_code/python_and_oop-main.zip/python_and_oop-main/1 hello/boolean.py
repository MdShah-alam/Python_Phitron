is_hungry = True
is_passed = True
is_single = False