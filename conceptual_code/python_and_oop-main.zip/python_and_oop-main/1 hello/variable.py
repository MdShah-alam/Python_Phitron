a = 3
b = 5
number = 66
my_number = 98
price = 45
age = 13
# print(price)
# print(age)
another_variable = price
# print(another_variable)
sum = price + age
print(sum)
triple = my_number + another_variable + sum