""" 
1. What is Python
2. python install
3. VS Code (python, code runner)
4. Variable
5. int
6. string
7. boolean
8. type
9. print
10. f string
11. input
12. Comment
 """

sum = 5

""" 
Home work

1. take three input from the user
2. add the three inputs and display the sum

3. take two numbers then show the multiplication
4. take first name and last name as input and display full name

5. take three inputs. and output will be like: 
"Hey I am ____. My age is __. I love to eat __."


6. (advanced) take one input and display 4 times of that number
7. (advanced) take degree C and covert the temperature to F 
 """