# Exploring python print command
# another line of comment
# I am learning Python
# Ctrl + /
# Alt + shift + A
print("Kopa Python")
print("kopa done") # same line comment

""" large multiline comment
    another lines of comment

 """
