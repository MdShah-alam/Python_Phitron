name = "Akbar Ali"
school = "Abu jhor gifari"
district = 'New California'
first_name = 'Asif'
last_name = 'Akbar'
full_name = first_name + ' ' + last_name
# print(name)
# print(district)
# print(full_name)
hobby = 'To play Football \nand watch cricket \nSleep at night'
print(hobby)