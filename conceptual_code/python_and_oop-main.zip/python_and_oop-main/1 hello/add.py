from cgitb import reset


num1 = input('Tell us the first number: ')
num2 = input('Tell use the second number: ')
num1_int = int(num1)
num2_int = int(num2)
result = num1_int + num2_int
print(result)