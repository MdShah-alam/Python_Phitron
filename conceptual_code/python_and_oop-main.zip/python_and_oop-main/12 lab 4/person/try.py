
from mankind import Human

male = Human(gender='male', height=45, weight=64)

print(male.height)