num1 = 5
num2 = 12
print( num1 + num2)
f_name = 'Alu'
l_name = 'Khan'
print(f_name + l_name)
nums_1 = [ 1, 2, 3, 4]
nums_2 = [41, 42, 43, 44]
print(nums_1 + nums_2)
is_learning = True
is_practicing = True
print(is_learning + is_practicing)