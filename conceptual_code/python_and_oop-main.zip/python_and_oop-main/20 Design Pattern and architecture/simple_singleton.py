class Company:
    def __init__(self, name, address) -> None:
        self.name = name
        self.address = address



grameen_phone = Company('Grameen Phone', 'boshundhara')