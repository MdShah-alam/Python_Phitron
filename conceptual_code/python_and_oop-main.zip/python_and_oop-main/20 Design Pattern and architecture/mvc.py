class Model:
    def __init__(self) -> None:
        pass

class ProductModel:
    pass

class View:
    pass

class Controller:
    pass