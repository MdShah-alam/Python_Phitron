# import math
from math import sin, ceil
import random 
import datetime as dt

# result = sin(30)
result = ceil(2.13)
# print(result)
num = random.random()
num = random.randint(70, 90)
winner = random.choice([4, 8, 91, 144, 20, 19, 56])
print(winner)
