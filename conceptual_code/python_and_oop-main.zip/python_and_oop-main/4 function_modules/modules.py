# from function import add, multiply
from function import *
from kargs import all_types as at

res = add(56,89)
print('res in modules.py', res)


# import function
# sum = function.add(45,56)
# print('sum in modules.py', sum)
# result = function.multiply(12,3)